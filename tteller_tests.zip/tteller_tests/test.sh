#! /bin/bash

python3 -m unittest discover tests